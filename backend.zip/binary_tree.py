from collections import deque
from html import escape
from pathlib import Path
from flask import Blueprint, Response, request, session

binary_tree_bp = Blueprint('binary_tree', __name__)


class Node:
    def __init__(self, value, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right

    def to_dict(self):
        return {
            'value': self.value,
            'left': self.left.to_dict() if self.left else None,
            'right': self.right.to_dict() if self.right else None,
        }

    @staticmethod
    def from_dict(data):
        if data is None:
            return None
        if not isinstance(data, dict) or not {'value', 'left', 'right'}.issubset(data):
            raise ValueError('Saved tree data has an invalid format.')
        return Node(
            data['value'],
            Node.from_dict(data['left']),
            Node.from_dict(data['right']),
        )


class BinaryTree:
    def __init__(self, root_value=None):
        self.root = (
            root_value if isinstance(root_value, Node)
            else Node(root_value) if root_value is not None
            else None
        )

    def level_order(self):
        """Yield (node, parent, side) in level order."""
        if self.root is None:
            return
        queue = deque([(self.root, None, None)])
        while queue:
            node, parent, side = queue.popleft()
            yield node, parent, side
            if node.left:
                queue.append((node.left, node, 'left'))
            if node.right:
                queue.append((node.right, node, 'right'))

    def search_node(self, key):
        return next((n for n, _, _ in self.level_order() if n.value == key), None)

    def find(self, key):
        return self.search_node(key)

    def insert_left(self, current_node, value):
        new_node = Node(value, left=current_node.left)
        current_node.left = new_node

    def insert_right(self, current_node, value):
        new_node = Node(value, right=current_node.right)
        current_node.right = new_node

    def insert_child(self, parent, value, side):
        if side == 'left':
            self.insert_left(parent, value)
        elif side == 'right':
            self.insert_right(parent, value)
        else:
            raise ValueError('Side must be "left" or "right".')

    def delete_node(self, key):
        """Copy the last level-order node into the target, then remove that node."""
        nodes = list(self.level_order())
        target = next((n for n, _, _ in nodes if n.value == key), None)
        if target is None:
            return False
        last, parent, side = nodes[-1]
        if last is self.root:
            self.root = None
        else:
            target.value = last.value
            setattr(parent, side, None)
        return True

    def delete(self, key):
        return self.delete_node(key)

    def preorder_traversal(self, start, traversal=''):
        if start:
            traversal += f'{start.value} '
            traversal = self.preorder_traversal(start.left, traversal)
            traversal = self.preorder_traversal(start.right, traversal)
        return traversal

    def inorder_traversal(self, start, traversal=''):
        if start:
            traversal = self.inorder_traversal(start.left, traversal)
            traversal += f'{start.value} '
            traversal = self.inorder_traversal(start.right, traversal)
        return traversal

    def postorder_traversal(self, start, traversal=''):
        if start:
            traversal = self.postorder_traversal(start.left, traversal)
            traversal = self.postorder_traversal(start.right, traversal)
            traversal += f'{start.value} '
        return traversal

    def preorder(self):
        out = []
        def walk(n):
            if n:
                out.append(n.value); walk(n.left); walk(n.right)
        walk(self.root)
        return out

    def inorder(self):
        out = []
        def walk(n):
            if n:
                walk(n.left); out.append(n.value); walk(n.right)
        walk(self.root)
        return out

    def postorder(self):
        out = []
        def walk(n):
            if n:
                walk(n.left); walk(n.right); out.append(n.value)
        walk(self.root)
        return out


def layout(root, dx=90, dy=105):
    """x = inorder position, y = depth. No overlaps, no extra bookkeeping."""
    nodes, edges, counter = [], [], [0]

    def walk(n, depth):
        if n is None:
            return None
        left_pos = walk(n.left, depth + 1)
        pos = {'value': n.value, 'x': 55 + counter[0] * dx, 'y': 55 + depth * dy}
        counter[0] += 1
        nodes.append(pos)
        right_pos = walk(n.right, depth + 1)
        for child in (left_pos, right_pos):
            if child:
                edges.append({'x1': pos['x'], 'y1': pos['y'] + 29,
                              'x2': child['x'], 'y2': child['y'] - 29})
        return pos

    walk(root, 0)
    return nodes, edges, max(1000, 110 + counter[0] * dx)


DEFAULT_TREE = Node(
    'R',
    Node('A', Node('C'), Node('D')),
    Node('B', Node('E'), Node('F', Node('G'))),
).to_dict()


def render_binary_tree_page(tree, tree_nodes, tree_edges, tree_width,
                            highlight, message, message_type, form_values):
    def traversal_items(values):
        return ''.join(f'<span>{escape(str(value))}</span>' for value in values)

    message_html = (
        f'<p class="binary-tree-message {escape(message_type)}" role="status">'
        f'{escape(message)}</p>'
        if message else '<p class="binary-tree-message" role="status"></p>'
    )

    if tree.root is None:
        visualization = '<p class="binary-tree-empty">The tree is empty.</p>'
    else:
        lines = ''.join(
            '<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}"/>'.format(**edge)
            for edge in tree_edges
        )
        nodes = ''.join(
            '<div class="reference-node{highlighted}" style="left: {x}px; top: {y}px;">{value}</div>'.format(
                highlighted=' is-highlighted' if item['value'] == highlight else '',
                x=item['x'],
                y=item['y'],
                value=escape(str(item['value'])),
            )
            for item in tree_nodes
        )
        visualization = (
            f'<div class="tree-reference" style="width: {tree_width}px;">'
            f'<svg class="tree-lines" viewBox="0 0 {tree_width} 560" aria-hidden="true">'
            f'<g>{lines}</g></svg>{nodes}</div>'
        )

    template_path = Path(__file__).parent / 'templates' / 'binary_tree.html'
    body = template_path.read_text(encoding='utf-8')
    replacements = {
        '__TREE_VALUE__': escape(form_values.get('value', ''), quote=True),
        '__PARENT_VALUE__': escape(form_values.get('parent_value', ''), quote=True),
        '<!-- BINARY_TREE_MESSAGE -->': message_html,
        '<!-- BINARY_TREE_VISUALIZATION -->': visualization,
        '<!-- TREE_PREORDER -->': traversal_items(tree.preorder()),
        '<!-- TREE_INORDER -->': traversal_items(tree.inorder()),
        '<!-- TREE_POSTORDER -->': traversal_items(tree.postorder()),
    }
    for placeholder, content in replacements.items():
        body = body.replace(placeholder, content)

    return Response(body, mimetype='text/html')


@binary_tree_bp.route('/works/binary-tree', methods=['GET', 'POST'])
def binary_tree():
    data = session['binary_tree_values'] if 'binary_tree_values' in session else DEFAULT_TREE
    invalid_saved_tree = False
    try:
        tree = BinaryTree(Node.from_dict(data))
    except ValueError:
        tree = BinaryTree(Node.from_dict(DEFAULT_TREE))
        session['binary_tree_values'] = DEFAULT_TREE
        invalid_saved_tree = True

    message, message_type, highlight = '', 'success', None
    if invalid_saved_tree:
        message = 'Saved tree data was invalid and has been reset.'
        message_type = 'warning'

    if request.method == 'POST':
        action = request.form.get('action', '')
        value = request.form.get('value', '').strip()
        try:
            if action == 'reset':
                tree = BinaryTree(Node.from_dict(DEFAULT_TREE))
                message = 'The binary tree was reset.'
            else:
                if not value:
                    raise ValueError('Enter a value.')

                if action == 'search':
                    highlight = value
                    found = tree.find(value) is not None
                    message = f'{value} was {"found" if found else "not found"} in the tree.'
                    message_type = 'success' if found else 'warning'

                elif action in ('insert_left', 'insert_right'):
                    parent_value = request.form.get('parent_value', '').strip()
                    if not parent_value:
                        raise ValueError('Enter the parent value.')
                    parent = tree.find(parent_value)
                    if parent is None:
                        raise ValueError(f'Parent {parent_value} was not found.')
                    if tree.find(value):
                        raise ValueError(f'{value} is already in the tree.')
                    side = action.removeprefix('insert_')
                    tree.insert_child(parent, value, side)
                    highlight = value
                    message = f'{value} was inserted {side} of {parent_value}.'

                elif action == 'delete':
                    if not tree.delete(value):
                        raise ValueError(f'{value} was not found in the tree.')
                    message = f'{value} was removed from the binary tree.'

                else:
                    raise ValueError('Choose a valid action.')

            session['binary_tree_values'] = tree.root.to_dict() if tree.root else None
        except ValueError as exc:
            message, message_type = str(exc), 'error'

    tree_nodes, tree_edges, tree_width = layout(tree.root)

    return render_binary_tree_page(
        tree, tree_nodes, tree_edges, tree_width,
        highlight, message, message_type,
        request.form if request.method == 'POST' else {},
    )