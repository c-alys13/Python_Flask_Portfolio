ALGORITHMS = (
    ('bubble', 'Bubble Sort'),
    ('selection', 'Selection Sort'),
    ('insertion', 'Insertion Sort'),
    ('merge', 'Merge Sort'),
    ('quick', 'Quick Sort'),
)


def parse_numbers(text):
    if not text or not text.strip():
        raise ValueError('Enter at least one number.')

    parts = text.replace(',', ' ').split()
    if len(parts) > 30:
        raise ValueError('Enter no more than 30 numbers.')

    try:
        numbers = [int(part) for part in parts]
    except ValueError as exc:
        raise ValueError('Use whole numbers separated by commas or spaces.') from exc
    return numbers


def bubble_sort(values):
    values = values.copy()
    steps = [{'array': values.copy(), 'description': 'Starting array'}]

    n = len(values)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if values[j] > values[j + 1]:
                values[j], values[j + 1] = values[j + 1], values[j]
                swapped = True
                steps.append({
                    'array': values.copy(),
                    'description': f'Swap positions {j + 1} and {j + 2}',
                })
        if not swapped:
            break

    steps.append({'array': values.copy(), 'description': 'Sorted array'})
    return values, steps


def selection_sort(values):
    values = values.copy()
    steps = [{'array': values.copy(), 'description': 'Starting array'}]

    for i in range(len(values)):
        min_index = i
        for j in range(i + 1, len(values)):
            if values[min_index] > values[j]:
                min_index = j
        values[i], values[min_index] = values[min_index], values[i]
        if min_index != i:
            steps.append({
                'array': values.copy(),
                'description': f'Move minimum {values[i]} to position {i + 1}',
            })

    steps.append({'array': values.copy(), 'description': 'Sorted array'})
    return values, steps


def insertion_sort(values):
    values = values.copy()
    steps = [{'array': values.copy(), 'description': 'Starting array'}]

    for i in range(1, len(values)):
        key = values[i]
        j = i - 1
        while j >= 0 and key < values[j]:
            values[j + 1] = values[j]
            j -= 1
            steps.append({
                'array': values.copy(),
                'description': f'Shift {key} into the sorted left portion',
            })
        values[j + 1] = key

    steps.append({'array': values.copy(), 'description': 'Sorted array'})
    return values, steps


def merge_sort(values):
    values = values.copy()
    steps = [{'array': values.copy(), 'description': 'Starting array'}]

    def merge_sort_range(start, end):
        if end - start <= 1:
            return

        middle = (start + end) // 2
        merge_sort_range(start, middle)
        merge_sort_range(middle, end)

        merged = values[start:end]
        left = merged[:middle - start]
        right = merged[middle - start:]
        left_index = 0
        right_index = 0
        destination = start

        while left_index < len(left) and right_index < len(right):
            if left[left_index] <= right[right_index]:
                values[destination] = left[left_index]
                left_index += 1
            else:
                values[destination] = right[right_index]
                right_index += 1
            destination += 1

        while left_index < len(left):
            values[destination] = left[left_index]
            left_index += 1
            destination += 1
        while right_index < len(right):
            values[destination] = right[right_index]
            right_index += 1
            destination += 1

        steps.append({
            'array': values.copy(),
            'description': f'Merge positions {start + 1} to {end}',
        })

    merge_sort_range(0, len(values))
    steps.append({'array': values.copy(), 'description': 'Sorted array'})
    return values, steps


def quick_sort(values):
    values = values.copy()
    steps = [{'array': values.copy(), 'description': 'Starting array'}]

    def partition(low, high):
        pivot = values[high]
        index = low
        for current in range(low, high):
            if values[current] <= pivot:
                values[index], values[current] = values[current], values[index]
                index += 1
        values[index], values[high] = values[high], values[index]
        steps.append({
            'array': values.copy(),
            'description': f'Place pivot {pivot} in position {index + 1}',
        })
        return index

    def quick_sort_range(low, high):
        if low >= high:
            return
        pivot_index = partition(low, high)
        quick_sort_range(low, pivot_index - 1)
        quick_sort_range(pivot_index + 1, high)

    quick_sort_range(0, len(values) - 1)
    steps.append({'array': values.copy(), 'description': 'Sorted array'})
    return values, steps


SORT_FUNCTIONS = {
    'bubble': bubble_sort,
    'selection': selection_sort,
    'insertion': insertion_sort,
    'merge': merge_sort,
    'quick': quick_sort,
}
