class QueueNode:
    def __init__(self, data):
        self.data = data
        self.next = None


class Queue:
    def __init__(self):
        self.front = None
        self.rear = None
        self.length = 0

    def enqueue(self, data):
        new_node = QueueNode(data)
        if self.rear is None:
            self.front = self.rear = new_node
        else:
            self.rear.next = new_node
            self.rear = new_node
        self.length += 1

    def dequeue(self):
        if self.is_empty():
            return None
        removed_data = self.front.data
        self.front = self.front.next
        if self.front is None:
            self.rear = None
        self.length -= 1
        return removed_data

    def peek(self):
        return None if self.front is None else self.front.data

    def is_empty(self):
        return self.length == 0

    def size(self):
        return self.length

    def to_list(self):
        values = []
        current = self.front
        while current is not None:
            values.append(current.data)
            current = current.next
        return values
