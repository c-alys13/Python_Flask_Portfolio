from linkedlist_operations import LinkedList


def run_linked_list_work(request):
    linked_list = LinkedList()
    for value in request.form.getlist('values'):
        value = value.strip()
        if value:
            linked_list.insert_at_end(value)

    message = None
    message_type = None

    if request.method == 'POST':
        action = request.form.get('action')
        value = request.form.get('value', '').strip()
        after_value = request.form.get('after_value', '').strip()
        value_actions = {
            'insert_beginning', 'insert_middle', 'insert_end',
            'insert_after', 'remove_value', 'search'
        }

        if action in value_actions and not value:
            message = 'You entered an empty value. Please enter a value.'
            message_type = 'error'
        elif action == 'insert_after' and not after_value:
            message = 'You entered an empty value for the node to insert after.'
            message_type = 'error'
        elif action == 'insert_beginning':
            linked_list.insert_at_beginning(value)
            message = f'Inserted {value!r} at the beginning.'
        elif action == 'insert_middle':
            linked_list.insert_at_middle(value)
            message = f'Inserted {value!r} in the middle.'
        elif action == 'insert_end':
            linked_list.insert_at_end(value)
            message = f'Inserted {value!r} at the end.'
        elif action == 'insert_after':
            if linked_list.insert_after(after_value, value) is None:
                message = f'{after_value!r} was not found.'
                message_type = 'error'
            else:
                message = f'Inserted {value!r} after {after_value!r}.'
        elif action == 'remove_beginning':
            removed = linked_list.remove_beginning()
            message = f'Removed {removed!r}.' if removed is not None else 'The list is empty.'
            message_type = 'success' if removed is not None else 'error'
        elif action == 'remove_end':
            removed = linked_list.remove_at_end()
            message = f'Removed {removed!r}.' if removed is not None else 'The list is empty.'
            message_type = 'success' if removed is not None else 'error'
        elif action == 'remove_value':
            removed = linked_list.remove_at(value)
            message = f'Removed {removed!r}.' if removed is not None else f'{value!r} was not found.'
            message_type = 'success' if removed is not None else 'error'
        elif action == 'search':
            found = linked_list.search(value)
            message = f'{value!r} is in the list.' if found else f'{value!r} is not in the list.'
            message_type = 'success' if found else 'error'
        elif action == 'clear':
            linked_list = LinkedList()
            message = 'The list has been cleared.'
        else:
            message = 'Choose a linked-list operation.'
            message_type = 'error'

    return linked_list.to_list(), message, message_type
