class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self.length = 0

    def insert_at_beginning(self, data):
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node
        if self.tail is None:
            self.tail = new_node
        self.length += 1

    def insert_at_end(self, data):
        new_node = Node(data)
        if self.tail is None:
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node
        self.length += 1

    def insert_at_middle(self, data):
        middle_index = self.length // 2
        if middle_index == 0:
            self.insert_at_beginning(data)
            return

        current_node = self.head
        for _ in range(middle_index - 1):
            current_node = current_node.next

        new_node = Node(data)
        new_node.next = current_node.next
        current_node.next = new_node
        if new_node.next is None:
            self.tail = new_node
        self.length += 1

    def insert_after(self, nodedata, data):
        current_node = self.head
        while current_node and current_node.data != nodedata:
            current_node = current_node.next
        if current_node is None:
            return None

        new_node = Node(data)
        new_node.next = current_node.next
        current_node.next = new_node
        if self.tail is current_node:
            self.tail = new_node
        self.length += 1
        return data

    def search(self, data):
        current_node = self.head
        while current_node:
            if current_node.data == data:
                return True
            current_node = current_node.next
        return False

    def remove_beginning(self):
        if self.head is None:
            return None

        removed_data = self.head.data
        self.head = self.head.next
        self.length -= 1
        if self.head is None:
            self.tail = None
        return removed_data

    def remove_at_end(self):
        if self.head is None:
            return None
        if self.head is self.tail:
            return self.remove_beginning()

        current_node = self.head
        while current_node.next is not self.tail:
            current_node = current_node.next

        removed_data = self.tail.data
        self.tail = current_node
        self.tail.next = None
        self.length -= 1
        return removed_data

    def remove_at(self, data):
        if self.head is None:
            return None
        if self.head.data == data:
            return self.remove_beginning()

        current_node = self.head
        while current_node.next and current_node.next.data != data:
            current_node = current_node.next
        if current_node.next is None:
            return None

        removed_data = current_node.next.data
        current_node.next = current_node.next.next
        if current_node.next is None:
            self.tail = current_node
        self.length -= 1
        return removed_data

    def to_list(self):
        values = []
        current_node = self.head
        while current_node:
            values.append(current_node.data)
            current_node = current_node.next
        return values
