import math

from stack import Stack


ORDER_OF_PRECEDENCE = {'+': 1, '-': 1, '*': 2, '/': 2, '^': 3}
ALLOWED_SYMBOLS = '()+-*/^'


def convert_to_uppercase(request):
    if request.method == 'POST':
        return request.form.get('inputString', '').upper()
    return None


def calculate_circle_area(request):
    result = None
    error = None

    if request.method == 'POST':
        try:
            radius = float(request.form.get('radius', ''))
        except ValueError:
            error = 'Error: You did not type a number.'
        else:
            if not math.isfinite(radius) or radius < 0:
                error = 'Please enter a valid non-negative number.'
            else:
                result = round(math.pi * radius ** 2, 2)

    return result, error


def calculate_triangle_area(request):
    result = None
    error = None

    if request.method == 'POST':
        try:
            base = float(request.form.get('base', ''))
            height = float(request.form.get('height', ''))
        except ValueError:
            error = 'Error: You did not type a number.'
        else:
            if (not math.isfinite(base) or not math.isfinite(height)
                    or base < 0 or height < 0):
                error = 'Please enter valid non-negative numbers.'
            else:
                result = round(0.5 * base * height, 2)

    return result, error


def split_into_tokens(expression):
    if expression is None:
        raise ValueError('Please enter an infix expression.')

    text = ''.join(character for character in expression
                   if not character.isspace())
    if not text:
        raise ValueError('Please enter an infix expression.')

    tokens = []
    buffer = ''
    previous = None

    for character in text:
        if character.isalnum():
            buffer += character
            previous = 'operand'
            continue

        if character not in ALLOWED_SYMBOLS:
            raise ValueError(f'Invalid character: {character}')

        if buffer:
            tokens.append(buffer)
            buffer = ''
            previous = 'operand'

        if character in '+-' and previous in (None, 'operator', '('):
            raise ValueError('Unary plus and minus are not supported.')

        tokens.append(character)
        previous = 'operator' if character not in '()' else character

    if buffer:
        tokens.append(buffer)
    if not tokens:
        raise ValueError('Please enter a valid infix expression.')

    return tokens


def is_valid_operand(token):
    return bool(token) and (
        token.isdigit() or (len(token) == 1 and token.isalpha())
    )


def convert_infix_to_postfix(expression, include_steps=False):
    operators = Stack()
    output = Stack()
    steps = []

    tokens = split_into_tokens(expression)
    for token in tokens:
        operator_before = stack_to_list(operators, top_first=True)
        if is_valid_operand(token):
            output.push(token)
            description = f'Operand {token} is added to the output.'
        elif token == '(':
            operators.push(token)
            description = 'Opening parenthesis is pushed onto the operator stack.'
        elif token == ')':
            while not operators.is_empty() and operators.peek() != '(':
                output.push(operators.pop())
            if operators.is_empty():
                raise ValueError('Mismatched parentheses.')
            operators.pop()
            description = 'Closing parenthesis pops operators until the opening parenthesis.'
        elif token in ORDER_OF_PRECEDENCE:
            while (not operators.is_empty()
                   and operators.peek() != '('
                   and ORDER_OF_PRECEDENCE[operators.peek()] >= ORDER_OF_PRECEDENCE[token]):
                output.push(operators.pop())
            operators.push(token)
            description = f'Operator {token} is pushed after higher-precedence operators are popped.'
        else:
            raise ValueError(f'Invalid token: {token}')
        if include_steps:
            steps.append({
                'token': token,
                'operators_before': operator_before,
                'operators': stack_to_list(operators, top_first=True),
                'output': stack_to_list(output, top_first=False),
                'description': description,
            })

    while not operators.is_empty():
        token = operators.pop()
        if token == '(':
            raise ValueError('Mismatched parentheses.')
        output.push(token)

    output_tokens = []
    while not output.is_empty():
        output_tokens.append(output.pop())
    output_tokens.reverse()

    separator = ' ' if any(len(token) > 1 for token in output_tokens) else ''
    result = separator.join(output_tokens)
    return (result, steps) if include_steps else result


def stack_to_list(stack, top_first):
    values = []
    current = stack.top
    while current is not None:
        values.append(current.data)
        current = current.next
    return values if top_first else list(reversed(values))
