from flask import Flask, render_template, request, session, url_for
from markupsafe import Markup

from linked_list import run_linked_list_work
from binary_tree import binary_tree_bp
from queue import Queue
from programs import (
    calculate_circle_area,
    calculate_triangle_area,
    convert_infix_to_postfix,
    convert_to_uppercase,
)
from sorting import ALGORITHMS, SORT_FUNCTIONS, parse_numbers

app = Flask(__name__)
app.register_blueprint(binary_tree_bp)
app.secret_key = 'flask-intro-queue-session'


@app.context_processor
def site_navigation():
    works_endpoints = {
        'works', 'touppercase', 'acircle', 'atriangle',
        'linkedlist', 'queue', 'infix_postfix', 'sorting', 'binary_tree.binary_tree'
    }
    current_endpoint = request.endpoint

    def current_page(endpoint):
        return ' aria-current="page"' if endpoint == current_endpoint else ''

    works_current = (
        ' aria-current="page"'
        if current_endpoint in works_endpoints else ''
    )

    navigation = f"""
    <header class="site-header">
        <a class="site-brand" href="{url_for('profile')}" aria-label="Ashley Carillo profile">
            <span class="site-brand-mark" aria-hidden="true">a.</span>
            <span>Ashley Carillo</span>
        </a>
        <nav class="site-nav" aria-label="Main navigation">
            <a href="{url_for('index')}"{current_page('index')}>Home</a>
            <a href="{url_for('profile')}"{current_page('profile')}>Profile</a>
            <a href="{url_for('works')}"{works_current}>Works</a>
            <a href="{url_for('contact')}"{current_page('contact')}>Contact</a>
        </nav>
        <a class="site-cta" href="{url_for('works')}">Explore my work</a>
    </header>
    """
    return {'site_navigation': Markup(navigation)}

@app.route('/')
def index(): return render_template('index.html')

@app.route('/profile')
def profile(): return render_template('profile.html')

@app.route('/works')
def works(): return render_template('works.html')

@app.route('/contact')
def contact(): return render_template('contact.html')

@app.route('/works/touppercase', methods=['GET', 'POST'])
def touppercase():
    result = convert_to_uppercase(request)
    return render_template('touppercase.html', result=result)

@app.route('/works/area/circle', methods=['GET', 'POST'])
def acircle():
    result, error = calculate_circle_area(request)
    return render_template('circle.html', result=result, error=error)

@app.route('/works/area/triangle', methods=['GET', 'POST'])
def atriangle():
    result, error = calculate_triangle_area(request)
    return render_template('triangle.html', result=result, error=error)

@app.route('/works/linkedlist', methods=['GET', 'POST'])
def linkedlist():
    values, message, message_type = run_linked_list_work(request)
    return render_template(
        'linkedlist.html', values=values,
        message=message, message_type=message_type
    )

@app.route('/works/queue', methods=['GET', 'POST'])
def queue():
    if 'queue_values' not in session:
        session['queue_values'] = ['A', 'B', 'C']

    queue_data = Queue()
    for value in session['queue_values']:
        queue_data.enqueue(value)

    message = 'Queue initialized with A, B, and C.'
    visualization = None

    if request.method == 'POST':
        action = request.form.get('action')
        before = queue_data.to_list()

        if action == 'enqueue':
            value = request.form.get('value', '').strip()
            if not value:
                message = 'Enter a value to enqueue.'
            else:
                queue_data.enqueue(value)
                message = f'Enqueued {value}.'
                visualization = [
                    {'title': 'Before enqueue', 'values': before, 'description': 'The new value waits outside the queue.'},
                    {'title': 'After enqueue', 'values': queue_data.to_list(), 'description': f'{value} was added at the rear.', 'active': value}
                ]
        elif action == 'dequeue':
            removed = queue_data.dequeue()
            message = (
                'Queue is empty.' if removed is None
                else f'Dequeued {removed}.'
            )
            visualization = [
                {'title': 'Before dequeue', 'values': before, 'description': 'The front item is removed first.'},
                {'title': 'After dequeue', 'values': queue_data.to_list(), 'description': 'The queue moves forward from the front.'}
            ]
        elif action == 'peek':
            front = queue_data.peek()
            message = (
                'Queue is empty.' if front is None
                else f'Front: {front}.'
            )
            visualization = [
                {'title': 'Peek result', 'values': before, 'description': 'Peeking only reads the front item.', 'active': front}
            ]
        elif action == 'empty':
            message = 'Queue is empty.' if queue_data.is_empty() else 'Queue is not empty.'
            visualization = [
                {'title': 'Empty check', 'values': before, 'description': message}
            ]
        elif action == 'size':
            message = f'Size: {queue_data.size()}.'
            visualization = [
                {'title': 'Size check', 'values': before, 'description': message}
            ]
        elif action == 'reset':
            queue_data = Queue()
            for value in ['A', 'B', 'C']:
                queue_data.enqueue(value)
            message = 'Queue reset to A, B, and C.'
            visualization = [
                {'title': 'Before reset', 'values': before, 'description': 'Reset replaces the current queue.'},
                {'title': 'After reset', 'values': queue_data.to_list(), 'description': message}
            ]

        session['queue_values'] = queue_data.to_list()

    values = queue_data.to_list()
    front = queue_data.peek()
    rear = values[-1] if values else None
    return render_template(
        'queue.html',
        values=values,
        message=message,
        size=queue_data.size(),
        front=front,
        rear=rear,
        visualization=visualization
    )

@app.route('/works/infix_postfix', methods=['GET', 'POST'])
def infix_postfix():
    result = error = None
    steps = []
    if request.method == 'POST':
        try:
            result, steps = convert_infix_to_postfix(
                request.form.get('infix', ''),
                include_steps=True
            )
        except ValueError as exc:
            error = str(exc)
    return render_template(
        'infix_postfix.html',
        result=result,
        error=error,
        steps=steps,
    )

@app.route('/works/sorting', methods=['GET', 'POST'])
def sorting():
    values = None
    algorithm = 'bubble'
    result = None
    steps = []
    error = None

    if request.method == 'POST':
        algorithm = request.form.get('algorithm', 'bubble')
        try:
            values = parse_numbers(request.form.get('numbers', ''))
            if algorithm not in SORT_FUNCTIONS:
                raise ValueError('Choose a valid sorting algorithm.')
            result, steps = SORT_FUNCTIONS[algorithm](values)
        except ValueError as exc:
            error = str(exc)

    algorithm_names = dict(ALGORITHMS)
    return render_template(
        'sorting.html',
        algorithms=ALGORITHMS,
        algorithm=algorithm,
        algorithm_name=algorithm_names.get(algorithm, 'Bubble Sort'),
        original=values,
        result=result,
        steps=steps,
        error=error,
    )


if __name__ == '__main__':
    app.run(debug=True)
