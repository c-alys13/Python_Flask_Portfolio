import math
from flask import Flask, render_template, request
from linked_list import LinkedList

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/profile')
def profile():
    return render_template('profile.html')


@app.route('/works', methods=['GET', 'POST'])
def works():
    return render_template('works.html')

@app.route('/works/touppercase', methods=['GET', 'POST'])
def touppercase():
    result = None
    if request.method == 'POST':
        input_string = request.form.get('inputString', '')
        result = input_string.upper()
    return render_template('touppercase.html', result=result)


@app.route('/works/area/circle', methods=['GET', 'POST'])
def acircle():
    result = None
    error = None
    if request.method == 'POST':
        try:
            radius = float(request.form.get('radius', ''))
        except ValueError:
            error = "Error: You did not type a number."
        else:
            if not math.isfinite(radius) or radius < 0:
                error = "Please enter a valid non-negative number."
            else:
                result = round(math.pi * radius ** 2, 2)
    return render_template('circle.html', result=result, error=error)


@app.route('/works/area/triangle', methods=['GET', 'POST'])
def atriangle():
    result = None
    error = None
    if request.method == 'POST':
        try:
            base = float(request.form.get('base', ''))
            height = float(request.form.get('height', ''))
        except ValueError:
            error = "Error: You did not type a number."
        else:
            if not math.isfinite(base) or not math.isfinite(height) or base < 0 or height < 0:
                error = "Please enter valid non-negative numbers."
            else:
                result = round(0.5 * base * height, 2)
    return render_template('triangle.html', result=result, error=error)


@app.route('/works/linkedlist', methods=['GET', 'POST'])
def linkedlist():
    linked_list = LinkedList()
    for value in request.form.getlist('values'):
        value = value.strip()
        if value:
            linked_list.insert_at_end(value)

    message = None
    message_type = None
    if request.method == 'POST':
        action = request.form.get('action')
        value = request.form.get('value', '').strip()
        after_value = request.form.get('after_value', '').strip()

        value_required_actions = {
            'insert_beginning',
            'insert_middle',
            'insert_end',
            'insert_after',
            'remove_value',
            'search',
        }
        if action in value_required_actions and not value:
            message = "You entered an empty value. Please enter a value."
            message_type = 'error'
        elif action == 'insert_after' and not after_value:
            message = "You entered an empty value for the node to insert after."
            message_type = 'error'
        elif action == 'insert_beginning':
            linked_list.insert_at_beginning(value)
            message = f"Inserted {value!r} at the beginning."
        elif action == 'insert_middle':
            linked_list.insert_at_middle(value)
            message = f"Inserted {value!r} in the middle."
        elif action == 'insert_end':
            linked_list.insert_at_end(value)
            message = f"Inserted {value!r} at the end."
        elif action == 'insert_after':
            if linked_list.insert_after(after_value, value) is None:
                message = f"{after_value!r} was not found."
                message_type = 'error'
            else:
                message = f"Inserted {value!r} after {after_value!r}."
        elif action == 'remove_beginning':
            removed = linked_list.remove_beginning()
            message = f"Removed {removed!r}." if removed is not None else "The list is empty."
            message_type = 'success' if removed is not None else 'error'
        elif action == 'remove_end':
            removed = linked_list.remove_at_end()
            message = f"Removed {removed!r}." if removed is not None else "The list is empty."
            message_type = 'success' if removed is not None else 'error'
        elif action == 'remove_value':
            removed = linked_list.remove_at(value)
            message = f"Removed {removed!r}." if removed is not None else f"{value!r} was not found."
            message_type = 'success' if removed is not None else 'error'
        elif action == 'search':
            found = linked_list.search(value)
            message = f"{value!r} is in the list." if found else f"{value!r} is not in the list."
            message_type = 'success' if found else 'error'
        elif action == 'clear':
            linked_list = LinkedList()
            message = "The list has been cleared."
        else:
            message = "Choose a linked-list operation."
            message_type = 'error'

    return render_template(
        'linkedlist.html',
        values=linked_list.to_list(),
        message=message,
        message_type=message_type,
    )


@app.route('/contact')
def contact():
    return render_template('contact.html')


if __name__ == "__main__":
    app.run(debug=True)